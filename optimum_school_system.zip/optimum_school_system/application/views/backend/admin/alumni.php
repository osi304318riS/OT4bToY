<hr> 
<div class="panel panel-gradient" >
 
 
				<img src="uploads/img/alumni.png"  alt="" />
	      
           
</div>